usuario1 = "procopio"
senha1 = "12345"

usuario2 = "paiva"
senha2 = "54321"

usuario = input("Digite o usuário: ")
senha = input("Digite a senha: ")

if (usuario == usuario1 and senha == senha1) or \
   (usuario == usuario2 and senha == senha2):
    print("Seja bem vindo!")
else:
    print("Usuário e senha não conferem")